﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Drew
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        string name = "";

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Application["DisplayName"] != null)
                name = (string)Application["DisplayName"];
                NameLbl.Text = name;

            if (Page.PreviousPage != null)
                {
                    // Page.PreviousPage indicates page from which the control came
                    TextBox tb = (TextBox)Page.PreviousPage.FindControl("TextBox4");
                    Label ans = (Label)Page.PreviousPage.FindControl("Label1");
                    if (tb.Text == "" && ans.Text == "")
                        NameLbl.Text = "Your name is unknown";
                    else
                        NameLbl.Text = "Your name is " + tb.Text + " and your result is " + ans.Text;
                }
                else // there is no previous page
                {
                    NameLbl.Text = "Your name is unknown";
                }

           

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            

            Application.Lock();
            NameLbl.Text = name;
            Application["DisplayName"] = name;
            Application.UnLock();

            
        }
    }
}