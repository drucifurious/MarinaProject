﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Drew
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string name = "";
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Application["DisplayName"] != null)
                name = (string)Application["DisplayName"];
                NameLbl.Text = name;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        public void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //public double num1 = Convert.ToDouble(TextBox1.Text);
            //public double num2 = Convert.ToDouble(TextBox2.Text);

            //public  double Result = num1 + num2;
            //Label1.Text = Result.ToString();
            
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            double num1 = Convert.ToDouble(TextBox2.Text);
            double num2 = Convert.ToDouble(TextBox1.Text);

            if (DropDownList1.Text == "Addition")
            {
                double Result1 = num1 + num2;
                Label1.Text = Result1.ToString();
            }
            else if (DropDownList1.Text == "Subtraction")
            {
                double Result1 = num1 - num2;
                Label1.Text = Result1.ToString();
            }

            else if (DropDownList1.Text == "Multiplication")
            {
                double Result1 = num1 * num2;
                Label1.Text = Result1.ToString();
            }

            else if (DropDownList1.Text == "Division")
            {
                double Result1 = num1 / num2;
                Label1.Text = Result1.ToString();
            }

            else
            { Label1.Text = "Please Enter the valid choice"; }
                  
            }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            

            Application.Lock();
            NameLbl.Text = name;
            Application["DisplayName"] = name;
            Application.UnLock();
        }
    }
}